package aldi.krobok.submissiondicoding;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;

public class ProcieIntelAdapter extends RecyclerView.Adapter<ProcieIntelAdapter.CardViewViewHolder> {
    private ArrayList<Procie> listProcie;
    private Context context;

    public ProcieIntelAdapter(ArrayList<Procie> list) {
        this.listProcie = list;
        this.context = context;
    }

    public interface OnItemClickCallback {
        void onItemClicked(Procie data);
    }


    @NonNull
    @Override
    public CardViewViewHolder onCreateViewHolder(@NonNull ViewGroup v, int viewType) {
        View view = LayoutInflater.from(v.getContext()).inflate(R.layout.item_cardview_procie, v, false);
        return new CardViewViewHolder(view);
    }

    private OnItemClickCallback onItemClickCallback;
    public void setOnItemClickCallback(OnItemClickCallback onItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback;
    }

    @Override
    public void onBindViewHolder(@NonNull final ProcieIntelAdapter.CardViewViewHolder holder, int position) {

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onItemClickCallback.onItemClicked(listProcie.get(holder.getAdapterPosition()));
            }
        });
        final Procie procie = listProcie.get(position);
        Glide.with(holder.itemView.getContext())
                .load(procie.getPhoto())
                .apply(new RequestOptions().override(350, 550))
                .into(holder.imgPhoto);
        holder.tvName.setText(procie.getName());
        holder.tvDetail.setText(procie.getDetail());
        holder.btnSumber.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Toast.makeText(holder.itemView.getContext(),"ark.intel.com", Toast.LENGTH_SHORT).show();
            }
        });


    }


    @Override
    public int getItemCount() {
        return listProcie.size();
    }

    public class CardViewViewHolder extends RecyclerView.ViewHolder {

        ImageView imgPhoto;
        TextView tvName, tvDetail;
        Button btnSumber;
        public CardViewViewHolder(@NonNull View itemView) {
            super(itemView);
            imgPhoto = itemView.findViewById(R.id.img_item_photo);
            tvName = itemView.findViewById(R.id.tv_item_name);
            tvDetail = itemView.findViewById(R.id.tv_item_detail);
            btnSumber = itemView.findViewById(R.id.btn_sumber);
        }
    }
}